<template>
  <div>
    Hellasdo {{msg}}!
  </div>
</template>

<script>
export default {
  data () {
    return {
      msg: 'world abc? whateveasdr'
    }
  }
}
</script>
