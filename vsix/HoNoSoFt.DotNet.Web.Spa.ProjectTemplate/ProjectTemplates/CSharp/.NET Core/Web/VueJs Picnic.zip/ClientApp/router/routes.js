import Home from '../pages/home.vue'

export const routes = [
  { name: 'home', path: '/', component: Home, display: 'Home' }
]
