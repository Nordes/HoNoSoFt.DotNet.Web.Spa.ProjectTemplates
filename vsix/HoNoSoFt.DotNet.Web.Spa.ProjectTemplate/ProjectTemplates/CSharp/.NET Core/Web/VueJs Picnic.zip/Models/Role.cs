namespace $safeprojectname$.Models
{
  public enum Role {
    Employee,
    President,
    StakeHolder,
  }
}